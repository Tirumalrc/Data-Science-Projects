
library(twitteR)
library(ROAuth)

cred <- OAuthFactory$new(consumerKey='joKIHhLyOoAoIwA2ydCsyAN8j',
                         consumerSecret='DDgv4yEMCROshIjySABBmSbHoQS212jEcX7lczhj0kZaiWfbTt', 
                         requestURL='https://api.twitter.com/oauth/request_token',
                         accessURL='https://api.twitter.com/oauth/access_token',
                         authURL='https://api.twitter.com/oauth/authorize')

save(cred, file="twitter authentication.Rdata")

load("twitter authentication.Rdata")

library(base64enc)
library(httpuv)

setup_twitter_oauth("joKIHhLyOoAoIwA2ydCsyAN8j",  "DDgv4yEMCROshIjySABBmSbHoQS212jEcX7lczhj0kZaiWfbTt", 
                    "2345314237-YFL21kQiF84PfkJhgkAYuE4sVDyBKxmaStiqSQl", 
                    "kDr77rAPR012WYilOtHbjHRbfIHM6OoN4gM6680cmUTkA")
Tweets <- userTimeline('Zomato', n = 100,includeRts = T)
TweetsDF <- twListToDF(Tweets)
dim(TweetsDF)
View(TweetsDF)

write.csv(TweetsDF, "Zomato.csv",row.names = F)

handleTweets <- searchTwitter('DataScience', n = 1000)

library(rtweet)

Zomato = searchTwitter("Zomato", n=1000)


library(stringr)
library(tm)
library(ggmap)
library(plyr)
library(dplyr)
library(wordcloud)


df1 <- twListToDF(Zomato)
myCorpus <- Corpus(VectorSource(df1$text))
removeURL <- function(x) gsub("http[^[:space:]]*", "", x)
myCorpus <- tm_map(myCorpus, content_transformer(removeURL))
removeNumPunct <- function(x) gsub("[^[:alpha:][:space:]]*", "", x)
myCorpus <- tm_map(myCorpus, content_transformer(removeNumPunct))

myCorpus <- tm_map(myCorpus, stripWhitespace)
myCorpusCopy <- myCorpus
myCorpus <- tm_map(myCorpus, stemDocument)
myCorpus <- Corpus(VectorSource(myCorpus))


wordFreq <- function(corpus, word) {
  results <- lapply(corpus,
                    function(x) { grep(as.character(x), pattern=paste0("\\<",word)) }
  )
  sum(unlist(results))
}
tdm <- TermDocumentMatrix(myCorpus,control = list(wordLengths = c(1, Inf)))

tdm



#most used words

(freq.terms <- findFreqTerms(tdm, lowfreq = 100))

#Removing ODD words

stpword= c(setdiff(stopwords('english'), c("r", "big")),"and", "when", "what", "to", "this","the","that","so","of","it","is","in","at","a","be","by","for","have","on","our","are","i","will","with","you")
 

myCorpus <- tm_map(myCorpus, removeWords, stpword)
library(wordcloud)
wordcloud(myCorpus ,max.words =150,min.freq=3,scale=c(4,.5),colors=palette())

tdm <- TermDocumentMatrix(myCorpus,control = list(wordLengths = c(1, Inf)))
tdm

(freq.terms <- findFreqTerms(tdm, lowfreq = 50))

library(ggplot2)
term.freq <- rowSums(as.matrix(tdm))
term.freq <- subset(term.freq, term.freq >= 50)
df2 <- data.frame(term = names(term.freq), freq = term.freq)
ggplot(df2, aes(x=term, y=freq)) + geom_bar(stat="identity") +xlab("Terms") + ylab("Count") + coord_flip() +theme(axis.text=element_text(size=7))

  ggtitle(Zomato)
  

  