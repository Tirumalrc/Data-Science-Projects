library(rvest)
library(magrittr)
library(XML)
a = 10
rev = NULL
url1 = "https://www.tripadvisor.in/Hotel_Review-g15149265-d2041908-Reviews"
url2 = "-Mayfair_Hideaway_Spa_Resort-Quitol_Canaguinim_South_Goa_District_Goa.html#REVIEWS"

for(i in 0:8){
  url<-read_html(as.character(paste(url1,i*a,url2,sep="")))
  ping<-url %>%
    html_nodes(".partial_entry") %>%
    html_text() 
  rev<-c(rev,ping)
}
rev
write.table(rev,"travel.txt")
